public class Main {
    public static void main(String[] args) {
        int i1 = 3;
        int i2 = 5;
        long l1 = 7;
        long l2 = 9;
        double d1 = 2;
        double d2 = 4;
        float f1 = 6;
        float f2 = 8;

        int vivod1 = i1 + i2;
        long vivod2 = l1 + l2;
        long vivod3 = i1 + l1;
        float vivod4 = i1 + f1;
        double vivod5 = i1 + d1;
        double vivod6 = l1 + d1;
        System.out.println(vivod1);
        System.out.println(vivod2);
        System.out.println(vivod3);
        System.out.println(vivod4);
        System.out.println(vivod5);
        System.out.println(vivod6);



        System.out.println("Hello world!");
    }
}