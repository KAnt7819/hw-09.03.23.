public class Main {
    public static final char Auto ='A';
    public static final char Bus = 'B';
    public static void main(String[] args) {
        boolean Kossboolean = true;
        byte Kossbyte = 12;
        short Kossshort = 183;
        int Kossint = 12345678;
        long Kosslong = 1l;
        float Kossfloat = 1.2f;
        double Kossdouble = 1.23;
        char Kosschar = Auto;
        System.out.println("Kossboolean:" + Kossboolean);
        System.out.println("Kossbyte:" + Kossbyte);
        System.out.println("Kossshort:" + Kossshort);
        System.out.println("Kossint:" + Kossint);
        System.out.println("Kosslong:" + Kosslong);
        System.out.println("Kossfloat:" + Kossfloat);
        System.out.println("Kossdouble:" + Kossdouble);
        System.out.println("Kosschar:" + Kosschar);
        Kossint = Kossint / 9;
        System.out.println("Kossintizm:" + Kossint);
        Kossboolean = false;
        System.out.println("Kossbooleanizm:" + Kossboolean);
        Kosschar = Bus;
        System.out.println("Kosscharizm:" + Kosschar);
                


    }
}