public class Main {
    public static void main(String[] args) {
        int Auto = 5;
        int Bus = 28;
        int Summa = Auto + Bus;
        System.out.println("Obschee kolichestvo chelovek:" + Summa);

        int minus = Bus - Auto;
        System.out.println("Is Busa pereseli v Auto:" +minus );

        int mult = Auto * Bus;
        System.out.println("resultat umnogenija:" + mult);

        int Wurstweight = 565;
        int kolichestwo = 7;
        int Weight = Wurstweight / kolichestwo;
        System.out.println("Weight:"+ Weight);

        int Weights = Wurstweight % kolichestwo;
        System.out.println("Weight s ostatkom:" + Weights);

    }
}