public class Main {
    public static void main(String[] args) {
        System.out.println(5 % 4);
        System.out.println(15 % 3);
        boolean x1 = 2 % 2 == 0;
        System.out.println("true chetnoe false nechetnoe:" + x1);

        boolean x2 = 7 % 2 == 0;
        System.out.println("true chetnoe false nechetnoe:" + x2);

        boolean x3 = 13 % 2 == 0;
        System.out.println("true chetnoe false nechetnoe:" + x3);

        boolean x4 = 14 % 2 == 0;
        System.out.println("true chetnoe false nechetnoe:" + x4);

        int f1 = 15 % 10;
        System.out.println(f1);
    }
}